<div class="site-menubar">
<div class="site-menubar-body">
<div>
<div>
<ul class="site-menu">
<li class="site-menu-category">GENERAL OPERATIONS</li>
<li class="site-menu-item"><a href="appointments" data-slug="uikit"> <i class="site-menu-icon fa fa-clock-o" aria-hidden="true"></i> <span class="site-menu-title">Scan Appointments</span> <!--span class="site-menu-arrow"></span--></a></li>
<li class="site-menu-item"><a href="calendar" data-slug="advanced"><i class="site-menu-icon fa fa-calendar" aria-hidden="true"></i><span class="site-menu-title">Calendar</span><!--span class="site-menu-arrow"></span--></a></li>
<li class="site-menu-item"><a href="searchdietitian" data-slug="advanced"><i class="site-menu-icon fa fa-calendar-o" aria-hidden="true"></i><span class="site-menu-title">Schedule New Appointment</span><!--span class="site-menu-arrow"></span--></a></li>
<li class="site-menu-item"><a href="companyresource" data-slug="advanced"><i class="site-menu-icon fa fa-download" aria-hidden="true"></i><span class="site-menu-title">Resource Center</span><!--span class="site-menu-arrow"></span--></a></li>
</ul>
</div>
</div>
</div>
<div class="site-menubar-footer"> <a href="editprofile" class="fold-show" data-placement="top" data-toggle="tooltip" data-original-title="Edit Profile"><span class="icon wb-edit" aria-hidden="true"></span></a> <a href="signout" data-placement="top" data-toggle="tooltip" data-original-title="Logout"><span class="fa fa-power-off fa-lg" aria-hidden="true"></span></a> </div>
</div>