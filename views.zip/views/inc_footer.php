<footer class="site-footer">
<div class="col-md-6">
<div class="site-footer-legal">&copy; <?php echo date("Y") ?> Family Food, LLC</div>
</div>

<div class="col-md-6">
<div class="site-footer-right">
<span id="siteseal"><script async type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=IY8VHOAYEjX4jxhbDYLSHgTiqaKZlNS1FxJ2W9P4YRCqPyGBcrEBuokkDRDj"></script></span>
</div>
</div>
</footer>