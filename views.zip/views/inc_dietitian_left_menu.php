<div class="site-menubar">
<div class="site-menubar-body">

<ul class="site-menu">
<li class="site-menu-category">APPOINTMENTS</li>
<!-- start company -->
<li class="site-menu-item"><a href="viewappointments" data-slug="layout"><i class="site-menu-icon fa fa-calendar-o" aria-hidden="true"></i><span class="site-menu-title">View Appointments</span> <!--span class="site-menu-arrow"></span--></a> 
	<li class="site-menu-item"><a href="walkin" data-slug="layout"><i class="site-menu-icon fa fa-user-plus" aria-hidden="true"></i><span class="site-menu-title">Walk-in Clients</span> <!--span class="site-menu-arrow"></span--></a> 

<!--ul class="site-menu-sub">

<li class="site-menu-item"><a class="animsition-link" href="user_index.php" data-slug="layout-grids"><i class="site-menu-icon" aria-hidden="true"></i> <span class="site-menu-title">Search for Dietitian</span></a></li>

<li class="site-menu-item"><a class="animsition-link" href="admin_company_add.php" data-slug="layout-headers"><i class="site-menu-icon " aria-hidden="true"></i> <span class="site-menu-title">Select Service</span></a></li>

</ul--> 

</li>
<li class="site-menu-category">Misc</li>
<li class="site-menu-item"><a href="resourcecenter" data-slug="layout"><i class="site-menu-icon fa fa-download" aria-hidden="true"></i><span class="site-menu-title">Resource Center</span></a></li>
<li class="site-menu-item"><a href="clientdetails" data-slug="layout"><i class="site-menu-icon fa fa-pencil-square-o" aria-hidden="true"></i><span class="site-menu-title">Edit Client Details</span></a></li>
<li class="site-menu-category">Session Notes Quickjump</li>
<li class="site-menu-item"><a href="sessionflow" data-slug="layout"><i class="site-menu-icon fa fa-drivers-license-o" aria-hidden="true"></i><span class="site-menu-title">Nutrition Assessment</span></a></li>
<li class="site-menu-item"> <a href="sessionReports" data-slug="page"> <i class="site-menu-icon fa fa-drivers-license-o" aria-hidden="true"></i> <span class="site-menu-title">Session Reports</span></a></li>
<!--li class="site-menu-item"><a href="sessionflow2" data-slug="layout"><i class="site-menu-icon fa fa-drivers-license-o" aria-hidden="true"></i><span class="site-menu-title">Diagnosis</span></a></li>
<li class="site-menu-item"><a href="sessionflow3" data-slug="layout"><i class="site-menu-icon fa fa-drivers-license-o" aria-hidden="true"></i> <span class="site-menu-title">Intervention</span></a></li>
<li class="site-menu-item"><a href="sessionNotesDaily" data-slug="layout"><i class="site-menu-icon fa fa-drivers-license-o" aria-hidden="true"></i> <span class="site-menu-title">Monitoring and Evaluation</span></a></li-->
<p>&nbsp;</p>
<!--div class="widget widget-shadow text-center">
<div class="widget-header">
<div class="widget-header-content">
<a class="avatar" href="javascript:void(0)" style="width:50%"><input class="img-responsive" data-target="#examplePositionCenterImage" data-toggle="modal" type="image" src="../assets/assets/images/chart_thumb.png"></a>
</div>
</div>
</div-->
</ul>
</div>

<div class="site-menubar-footer">
<a href="editprofile" class="fold-show" data-placement="top" data-toggle="tooltip" data-original-title="Edit Profile"><span class="icon wb-edit" aria-hidden="true"></span></a>
<a href="changepassword" data-placement="top" data-toggle="tooltip" data-original-title="Change Password"><span class="icon wb-lock" aria-hidden="true"></span></a>
<a href="signout" data-placement="top" data-toggle="tooltip" data-original-title="Sign Out"><span class="icon wb-power" aria-hidden="true"></span> </a> </div>
</div>

<!--div class="site-gridmenu">

<ul>

<li> <a href="apps/mailbox/mailbox.html"> <i class="icon wb-envelope"></i> <span>Mailbox</span> </a> </li>

<li> <a href="apps/calendar/calendar.html"> <i class="icon wb-calendar"></i> <span>Calendar</span> </a> </li>

<li> <a href="apps/contacts/contacts.html"> <i class="icon wb-user"></i> <span>Contacts</span> </a> </li>

<li> <a href="apps/media/overview.html"> <i class="icon wb-camera"></i> <span>Media</span> </a> </li>

<li> <a href="apps/documents/categories.html"> <i class="icon wb-order"></i> <span>Documents</span> </a> </li>

<li> <a href="apps/projects/projects.html"> <i class="icon wb-image"></i> <span>Project</span> </a> </li>

<li> <a href="apps/forum/forum.html"> <i class="icon wb-chat-group"></i> <span>Forum</span> </a> </li>

<li> <a href="index.php"> <i class="icon wb-dashboard"></i> <span>Dashboard</span> </a> </li>

</ul>

</div-->